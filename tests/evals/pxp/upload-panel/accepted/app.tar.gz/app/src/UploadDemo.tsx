import { useState } from "react";
import UploadStatus, { type UploadItem } from "./UploadStatus";
import fixture from "./upload-state.json";

export default function UploadDemo({
  isolated = false,
}: {
  isolated?: boolean;
}) {
  const [items, setItems] = useState<UploadItem[]>(
    fixture.items as UploadItem[],
  );
  const remove = (id: string) =>
    setItems((current) => current.filter((item) => item.id !== id));
  return (
    <div className={isolated ? "upload-preview" : "upload-demo-dock"}>
      {!isolated && (
        <span className="upload-demo-label">
          Local upload demo · no files transferred
        </span>
      )}
      <UploadStatus
        items={items}
        destination={fixture.destination}
        title={
          items.length === fixture.items.length ? fixture.title : undefined
        }
        progress={50.7}
        onCancel={remove}
        onDismiss={remove}
        onCancelAll={() =>
          setItems((current) =>
            current.filter((item) => item.status !== "uploading"),
          )
        }
        onRetry={(id) =>
          setItems((current) =>
            current.map((item) =>
              item.id === id
                ? { ...item, status: "uploading", detail: "Uploading 1.2MB..." }
                : item,
            ),
          )
        }
      />
    </div>
  );
}

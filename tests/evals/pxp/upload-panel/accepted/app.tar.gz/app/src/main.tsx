import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import UploadDemo from "./UploadDemo";
import "./styles.css";
import "./theme.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    {window.location.pathname === "/upload-preview" ? (
      <UploadDemo isolated />
    ) : (
      <App />
    )}
  </StrictMode>,
);

import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { expect, it, vi } from "vitest";
import axe from "axe-core";
import UploadDemo from "./UploadDemo";
import UploadStatus, { type UploadItem } from "./UploadStatus";
import fixture from "./upload-state.json";

it("starts with the supplied seven items and cancels only the selected active item", async () => {
  const user = userEvent.setup();
  render(<UploadDemo isolated />);
  expect(screen.getAllByRole("listitem")).toHaveLength(7);
  expect(screen.getByRole("heading")).toHaveTextContent(fixture.title);
  await user.click(
    screen.getByRole("button", { name: "Cancel IMG_20240303_142512.jpg" }),
  );
  expect(screen.getAllByRole("listitem")).toHaveLength(6);
  expect(screen.queryByText("IMG_20240303_142512.jpg")).not.toBeInTheDocument();
  expect(screen.getByText("Couldn't upload file")).toBeInTheDocument();
});

it("Cancel all preserves failed and completed items, and Retry returns a failure to uploading", async () => {
  const user = userEvent.setup();
  render(<UploadDemo isolated />);
  await user.click(screen.getByRole("button", { name: "Cancel all" }));
  expect(screen.getAllByRole("listitem")).toHaveLength(5);
  expect(screen.getAllByText("Uploaded 1.2MB")).toHaveLength(4);
  expect(screen.getByText("Couldn't upload file")).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "Cancel all" })).toBeDisabled();
  await user.click(
    screen.getByRole("button", { name: "Retry Wire – New Features" }),
  );
  expect(screen.queryByText("Couldn't upload file")).not.toBeInTheDocument();
  expect(screen.getByText("Uploading 1.2MB...")).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "Cancel all" })).toBeEnabled();
  await user.click(screen.getByRole("button", { name: "Cancel all" }));
  expect(screen.getAllByRole("listitem")).toHaveLength(4);
  expect(screen.getByRole("heading")).toHaveTextContent("Uploads: 4 items");
});

it("supports keyboard collapse and expansion without losing the list state", async () => {
  const user = userEvent.setup();
  render(<UploadDemo isolated />);
  await user.tab();
  expect(screen.getByRole("button", { name: "Cancel all" })).toHaveFocus();
  await user.tab();
  const toggle = screen.getByRole("button", { name: "Collapse upload list" });
  expect(toggle).toHaveFocus();
  await user.keyboard("{Enter}");
  expect(toggle).toHaveAttribute("aria-expanded", "false");
  expect(screen.queryByRole("list")).not.toBeInTheDocument();
  await user.keyboard(" ");
  expect(toggle).toHaveAttribute("aria-expanded", "true");
  expect(screen.getAllByRole("listitem")).toHaveLength(7);
});

it("dismisses a failed item separately from canceling an active upload", async () => {
  const user = userEvent.setup();
  render(<UploadDemo isolated />);
  await user.click(
    screen.getByRole("button", {
      name: "Dismiss failed upload Wire – New Features",
    }),
  );
  expect(screen.getAllByRole("listitem")).toHaveLength(6);
  expect(screen.getAllByText("Uploading 1.2MB...")).toHaveLength(2);
});

it("supports controlled data, empty state, independent instances, and progress clamping", async () => {
  const cancel = vi.fn();
  const props = {
    items: fixture.items as UploadItem[],
    onCancel: cancel,
    onCancelAll: vi.fn(),
    onRetry: vi.fn(),
  };
  const { rerender } = render(<UploadStatus {...props} progress={120} />);
  expect(screen.getByRole("progressbar")).toHaveAttribute(
    "aria-valuenow",
    "100",
  );
  await userEvent.click(
    screen.getByRole("button", { name: "Cancel IMG_20240303_142512.jpg" }),
  );
  expect(cancel).toHaveBeenCalledWith("upload-2");
  expect(screen.getAllByRole("listitem")).toHaveLength(7);
  rerender(
    <>
      <UploadStatus {...props} items={[]} />
      <UploadStatus {...props} initiallyExpanded={false} />
    </>,
  );
  const regions = screen.getAllByRole("region");
  expect(within(regions[0]).getByText("No uploads")).toBeInTheDocument();
  expect(within(regions[1]).queryByRole("list")).not.toBeInTheDocument();
  const controls = screen
    .getAllByRole("button", { name: /upload list/ })
    .map((button) => button.getAttribute("aria-controls"));
  expect(new Set(controls).size).toBe(2);
});

it("has no automated accessibility violations", async () => {
  const { container } = render(<UploadDemo isolated />);
  expect(
    (
      await axe.run(container, {
        rules: { "color-contrast": { enabled: false } },
      })
    ).violations,
  ).toEqual([]);
});

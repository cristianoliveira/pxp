import { useId, useState } from "react";
import { ChevronDown, RotateCcw, X } from "lucide-react";
import "./UploadStatus.css";

export type UploadItem = {
  id: string;
  name: string;
  kind: "file" | "image" | "spreadsheet" | "presentation" | "audio" | "video";
  status: "uploading" | "failed" | "completed";
  detail: string;
};

export interface UploadStatusProps {
  items: readonly UploadItem[];
  destination?: string;
  title?: string;
  /** Aggregate progress, from 0 to 100. Omit if unknown. */
  progress?: number;
  initiallyExpanded?: boolean;
  onCancel: (id: string) => void;
  onCancelAll: () => void;
  onRetry: (id: string) => void;
  onDismiss?: (id: string) => void;
}

function StatusIcon({ item }: { item: UploadItem }) {
  const active = item.status === "uploading";
  const failed = item.status === "failed";
  return (
    <svg
      className={`upload-symbol ${active ? "uploading" : failed ? "failed" : item.kind}`}
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {active ? (
        <>
          <circle cx="12" cy="12" r="11" strokeOpacity=".15" />
          <path d="M12 1a11 11 0 1 1-6.5 19.88" />
          <path d="M12 16V8m-4 4 4-4 4 4" />
        </>
      ) : failed ? (
        <>
          <circle cx="12" cy="12" r="11" strokeOpacity=".15" />
          <path
            d="m11.1 7.8-3.6 7a1 1 0 0 0 .9 1.4h7.2a1 1 0 0 0 .9-1.4l-3.6-7a1 1 0 0 0-1.8 0Z"
            strokeWidth="1.2"
          />
          <path d="M12 10v2.5m0 1.6v.1" strokeWidth="1.2" />
        </>
      ) : (
        <>
          <path
            d="M6 1h12a3 3 0 0 1 3 3v13l-5 6H6a3 3 0 0 1-3-3V4a3 3 0 0 1 3-3Z"
            fill="currentColor"
            fillOpacity=".09"
          />
          <path d="M16 23v-3a3 3 0 0 1 3-3h2" />
          {item.kind === "spreadsheet" ? (
            <>
              <rect x="7" y="7" width="10" height="7" rx="1" />
              <path d="M7 10h10m-6-3v7" />
            </>
          ) : item.kind === "presentation" ? (
            <>
              <rect x="7" y="7" width="10" height="7" rx="1" />
              <path d="M12 14v3m-2 0h4" />
            </>
          ) : item.kind === "audio" ? (
            <>
              <path d="M10 14V8l7-2v7M10 10l7-2" />
              <ellipse cx="8.5" cy="15" rx="1.5" ry="2" />
              <ellipse cx="15.5" cy="14" rx="1.5" ry="2" />
            </>
          ) : item.kind === "video" ? (
            <path d="M9 8.2v7.6a.6.6 0 0 0 .9.5l5.8-3.8a.6.6 0 0 0 0-1L9.9 7.7a.6.6 0 0 0-.9.5Z" />
          ) : (
            <path d="M8 8h8m-8 4h6" />
          )}
        </>
      )}
    </svg>
  );
}

/** Controlled upload presentation. No file IO, timers, or network requests. */
export default function UploadStatus({
  items,
  destination,
  title,
  progress,
  initiallyExpanded = true,
  onCancel,
  onCancelAll,
  onRetry,
  onDismiss,
}: UploadStatusProps) {
  const [expanded, setExpanded] = useState(initiallyExpanded);
  const id = useId();
  const active = items.some((item) => item.status === "uploading");
  const heading =
    title ??
    `${active ? "Uploading" : "Uploads:"} ${items.length} ${items.length === 1 ? "item" : "items"}`;
  return (
    <section className="upload-status" aria-labelledby={`${id}-title`}>
      <header className="upload-header">
        <div className="upload-heading">
          <h2 id={`${id}-title`} aria-live="polite">
            {heading}
          </h2>
          {destination && <p>{destination}</p>}
        </div>
        <button
          type="button"
          className="upload-cancel-all"
          onClick={onCancelAll}
          disabled={!active}
        >
          Cancel all
        </button>
        <button
          type="button"
          className="upload-action upload-toggle"
          aria-label={expanded ? "Collapse upload list" : "Expand upload list"}
          aria-expanded={expanded}
          aria-controls={`${id}-list`}
          onClick={() => setExpanded(!expanded)}
        >
          <ChevronDown size={24} className={expanded ? "" : "is-collapsed"} />
        </button>
        {active && progress !== undefined && (
          <div
            className="upload-progress"
            role="progressbar"
            aria-label="Overall upload progress"
            aria-valuenow={Math.max(0, Math.min(100, progress))}
            aria-valuemin={0}
            aria-valuemax={100}
            style={{ width: `${Math.max(0, Math.min(100, progress))}%` }}
          />
        )}
      </header>
      <ul className="upload-list" id={`${id}-list`} hidden={!expanded}>
        {items.map((item) => (
          <li className="upload-row" key={item.id}>
            <StatusIcon item={item} />
            <div className="upload-copy">
              <div className="upload-name" title={item.name}>
                {item.name}
              </div>
              <div
                className={`upload-detail ${item.status}`}
                aria-live="polite"
              >
                {item.detail}
              </div>
            </div>
            <div className="upload-actions">
              {item.status === "failed" && (
                <button
                  type="button"
                  className="upload-action"
                  aria-label={`Retry ${item.name}`}
                  onClick={() => onRetry(item.id)}
                >
                  <RotateCcw size={18} />
                </button>
              )}
              {item.status === "uploading" && (
                <button
                  type="button"
                  className="upload-action"
                  aria-label={`Cancel ${item.name}`}
                  onClick={() => onCancel(item.id)}
                >
                  <X size={18} />
                </button>
              )}
              {item.status === "failed" && onDismiss && (
                <button
                  type="button"
                  className="upload-action"
                  aria-label={`Dismiss failed upload ${item.name}`}
                  onClick={() => onDismiss(item.id)}
                >
                  <X size={18} />
                </button>
              )}
            </div>
          </li>
        ))}
        {items.length === 0 && <li className="upload-empty">No uploads</li>}
      </ul>
    </section>
  );
}
